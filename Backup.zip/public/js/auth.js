console.log("Auth module loaded");
