const socket = io();
const statusEl = document.getElementById("status");
const messagesEl = document.getElementById("messages");
const joinBtn = document.getElementById("joinBtn");
const sendBtn = document.getElementById("sendBtn");

joinBtn.addEventListener("click", () => {
  const playerName = document.getElementById("playerName").value.trim();
  const roomName = document.getElementById("roomName").value.trim();

  if (!playerName || !roomName) {
    statusEl.textContent = "Заповніть ім'я та кімнату";
    return;
  }

  socket.emit("join-room", roomName);
  statusEl.textContent = `Підключено до кімнати ${roomName}`;
  addMessage(`Ви приєдналися як ${playerName}`);
});

sendBtn.addEventListener("click", () => {
  const roomName = document.getElementById("roomName").value.trim();
  const messageInput = document.getElementById("messageInput");
  const text = messageInput.value.trim();

  if (!text || !roomName) return;

  socket.emit("send-message", { room: roomName, text });
  messageInput.value = "";
});

socket.on("receive-message", (payload) => {
  addMessage(payload.text);
});

function addMessage(text) {
  const item = document.createElement("li");
  item.textContent = text;
  messagesEl.appendChild(item);
}
