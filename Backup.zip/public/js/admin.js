const socket = io();
const statusEl = document.getElementById("status");
const eventsEl = document.getElementById("events");
const createBtn = document.getElementById("createBtn");

createBtn.addEventListener("click", () => {
  const roomName = document.getElementById("roomName").value.trim();
  if (!roomName) return;

  socket.emit("join-room", roomName);
  addEvent(`Кімната ${roomName} створена/відкрита`);
  statusEl.textContent = `Кімната ${roomName} активна`;
});

socket.on("joined-room", (room) => {
  addEvent(`Приєднано до кімнати: ${room}`);
});

function addEvent(text) {
  const item = document.createElement("li");
  item.textContent = text;
  eventsEl.appendChild(item);
}
